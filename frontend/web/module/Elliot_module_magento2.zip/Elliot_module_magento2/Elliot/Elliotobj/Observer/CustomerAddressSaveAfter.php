<?php
namespace Elliot\Elliotobj\Observer;

use Magento\Framework\Event\ObserverInterface;

class CustomerAddressSaveAfter implements ObserverInterface {
    protected $customer;
    protected $storeManager;
    
    public function __construct(
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Customer\Api\CustomerRepositoryInterface $customer)
    {
        $this->customer = $customer;
        $this->storeManager = $storeManager;
    }
    
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $customer = $observer->getEvent()->getCustomerAddress();
        //echo "<pre>"; print_r($customer->getData());
        $customer_address_data = array();
        $customer_address_data['fistname'] = $customer->getFirstname();
        $customer_address_data['lastname'] = $customer->getLastname();
        $customer_address_data['street'] = $customer->getStreet();
        $customer_address_data['city'] = $customer->getCity();
        $customer_address_data['country_id'] = $customer->getCountryId();
        $customer_address_data['region'] = $customer->getRegion();
        $customer_address_data['postcode'] = $customer->getPostcode();
        $customer_address_data['telephone'] = $customer->getTelephone();
        $customer_address_data['customer_id'] = $customer->getCustomerId();
        $customer_address_data['magento_url'] = $this->storeManager->getStore()->getBaseUrl();
        
        $data = urlencode(json_encode($customer_address_data));
        $url_data = 'data='.$data;
        $link = 'https://elliot.global/magento2/magento2-customer-address-update?'.$url_data;
        
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => $link,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => false,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_SSL_VERIFYPEER=> false,
            CURLOPT_HTTPHEADER => array(
                "cache-control: no-cache",
                "postman-token: 13021bca-a51d-4711-2046-c6f02e0bf74d"
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

//        if ($err) {
//            echo "cURL Error #:" . $err;
//        } else {
//            echo $response;
//        }
        //die('That sit !');
    }
}