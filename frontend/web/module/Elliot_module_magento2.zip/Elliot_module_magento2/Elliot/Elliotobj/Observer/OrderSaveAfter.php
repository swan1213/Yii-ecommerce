<?php
namespace Elliot\Elliotobj\Observer;

use Magento\Framework\Event\ObserverInterface;

/**
 * Class OrderSaveAfter
 */
class OrderSaveAfter implements ObserverInterface
{
    protected $_order;
    protected $storeManager;
		
    public function __construct(
        \Magento\Sales\Api\Data\OrderInterface $order,
        \Magento\Store\Model\StoreManagerInterface $storeManager
    ) {
        $this->_order = $order;
        $this->storeManager = $storeManager;
    }

    /**
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return void
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {	
        $order_data = $observer->getEvent()->getOrder();
        //$order->save();
        //$orderid = $order->getId();
        $order_detail = array();
        $order_detail['magento_url'] = $this->storeManager->getStore()->getBaseUrl();
        $order_detail['order_id'] = $order_data->getId();
        $order_detail['order_state'] = $order_data->getState();
        $order_detail['order_status'] = $order_data->getStatus();
        $order_detail['order_store_id'] = $order_data->getStoreId();
        $order_detail['order_total'] = $order_data->getBaseGrandTotal();
        $order_detail['customer_email'] = $order_data->getCustomerEmail();
        $order_detail['order_shipping_amount'] = $order_data->getBaseShippingAmount();
        $order_detail['base_tax_amount'] = $order_data->getBaseTaxAmount();
        $order_detail['order_product_qty'] = $order_data->getTotalQtyOrdered();
        $order_detail['customer_id'] = $order_data->getCustomerId();
        $order_detail['order_created_at'] = $order_data->getCreatedAt();
        $order_detail['order_updated_at'] = $order_data->getUpdatedAt();
        $order_detail['refund_amount'] = $order_data->getSubtotalRefunded();
        $order_detail['discount_amount'] = $order_data->getDiscountAmount();
        $order_detail['shipping_method'] = $order_data->getShippingMethod();
        $order_detail['payment_method'] = $order_data->getPayment()->getMethodInstance()->getCode();

        $order_shipping_add = $order_data->getShippingAddress();
        //echo "<pre>"; print_r($order_shipping_add->getData());
        $shipping_details = array();
        $shipping_details['region'] = $order_shipping_add->getRegion();
        $shipping_details['postcode'] = $order_shipping_add->getPostcode();
        $shipping_details['street'] = $order_shipping_add->getStreet();
        $shipping_details['city'] = $order_shipping_add->getCity();
        $shipping_details['email'] = $order_shipping_add->getEmail();
        $shipping_details['telephone'] = $order_shipping_add->getTelephone();
        $shipping_details['country_id'] = $order_shipping_add->getCountryId();
        $shipping_details['firstname'] = $order_shipping_add->getFirstname();
        $shipping_details['lastname'] = $order_shipping_add->getLastname();
        $shipping_details['middlename'] = $order_shipping_add->getMiddlename();
        $order_detail['shipping_detail'] = $shipping_details;

        $order_billing_add = $order_data->getBillingAddress();
        //echo "<pre>"; print_r($order_billing_add->getData());
        $billing_details = array();
        $billing_details['region'] = $order_billing_add->getRegion();
        $billing_details['postcode'] = $order_billing_add->getPostcode();
        $billing_details['street'] = $order_billing_add->getStreet();
        $billing_details['city'] = $order_billing_add->getCity();
        $billing_details['email'] = $order_billing_add->getEmail();
        $billing_details['telephone'] = $order_billing_add->getTelephone();
        $billing_details['country_id'] = $order_billing_add->getCountryId();
        $billing_details['firstname'] = $order_billing_add->getFirstname();
        $billing_details['lastname'] = $order_billing_add->getLastname();
        $billing_details['middlename'] = $order_billing_add->getMiddlename();
        $order_detail['billing_detail'] = $billing_details;
        
        $orderItems = $order_data->getAllVisibleItems();
        
        
        foreach($orderItems as $_items)
        {
            $items = array();
            $items['name'] = $_items->getName();
            $items['qty_ordered'] = (int)$_items->getQtyOrdered();
            $items['price'] = $_items->getPrice();
            $items['sku'] = $_items->getSku();
            $items['product_id'] = $_items->getProductId();
            $items['weight'] = $_items->getWeight();
            $order_items_collection[] = $items;
        }
        $order_detail['order_items'] = $order_items_collection;
        //echo "<pre>"; print_r($order_items_collection); echo "<br>";  print_r($order_detail); die('End herer');
        
        $data = urlencode(json_encode($order_detail));
        $url_data = 'data='.$data;
        $link = 'https://elliot.global/magento2/magento2-order-create?'.$url_data;
        
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => $link,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => false,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_SSL_VERIFYPEER=> false,
            CURLOPT_HTTPHEADER => array(
                "cache-control: no-cache",
                "postman-token: 13021bca-a51d-4711-2046-c6f02e0bf74d"
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

//        if ($err) {
//            echo "cURL Error #:" . $err;
//        } else {
//            echo $response;
//        }
//        die('End herer!');
    }

}  