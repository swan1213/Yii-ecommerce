<?php
namespace Elliot\Elliotobj\Observer;

use Magento\Framework\Event\ObserverInterface;

class ObserverProductSave implements ObserverInterface {

    protected $catalogProductHelper;
    protected $stock;
    protected $storeManager;

    public function __construct(
            \Magento\Catalog\Helper\Product $catalogProductHelper,
            \Magento\CatalogInventory\Model\Stock\StockItemRepository $stock,
            \Magento\Store\Model\StoreManagerInterface $storeManager)
    {
        $this->catalogProductHelper = $catalogProductHelper;
        $this->stock = $stock;
        $this->storeManager = $storeManager;
    }

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $product = $observer->getProduct();
        
        $product_data = array();
        $stor_url = $this->storeManager->getStore()->getBaseUrl();
        $product_data['magento_url'] =  $stor_url;
        $product_data['product_id'] = $product->getId();
        $product_data['name'] = $product->getName();
        $product_data['sku'] = $product->getSku();
        $product_data['description'] = $product->getDescription();
        $product_data['weight'] = $product->getWeight();
        $product_data['status'] = $product->getStatus();
        $product_data['price'] = $product->getPrice();
        $product_data['product_created_at'] = $product->getCreated_at();
        $product_data['product_updated_at'] = $product->getUpdated_at();
        $product_data['product_url'] = $stor_url.$product->getProductUrl().'.html';
        $images = $product->getMediaGalleryImages();
        
        $product_img_array = array();
        $product_position_array = array();
        foreach($images as $_image)
        {
            if($_image->getPositionDefault()==1)
            {
                $product_data['base_img'] = $_image->getUrl();
            }
            $product_img_array[] = $_image->getUrl();
            $product_position_array[] = $_image->getPosition();
        }
        
        $product_data['images'] = $product_img_array;
        $product_data['position'] = $product_position_array;
        $product_data['categories'] = $product->getCategoryIds();
        $product_data['store_id'] = $product->getStoreIds();
        $productStock =  $this->stock->get($product->getId());
        $product_data['qty'] = $productStock->getQty();
        $product_data['is_in_stock'] = $productStock->getIsInStock();
        
        //echo "<pre>"; print_r($product_data);
        
        $data = urlencode(json_encode($product_data));
        $url_data = 'data='.$data;
        $link = 'https://elliot.global/magento2/magento2-product-create?'.$url_data;
        
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => $link,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => false,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_SSL_VERIFYPEER=> false,
            CURLOPT_HTTPHEADER => array(
                "cache-control: no-cache",
                "postman-token: 13021bca-a51d-4711-2046-c6f02e0bf74d"
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

//        if ($err) {
//            echo "cURL Error #:" . $err;
//        } else {
//            echo $response;
//        }
//        
//        die('End herere');

    }
}  