<?php
namespace Elliot\Elliotobj\Observer;

use Magento\Framework\Event\ObserverInterface;

class CustomerSaveAfter implements ObserverInterface {
    protected $customer;
    protected $storeManager;
    
    public function __construct(
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Customer\Api\CustomerRepositoryInterface $customer)
    {
        $this->customer = $customer;
        $this->storeManager = $storeManager;
    }
    
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $customer = $observer->getEvent()->getCustomer();
        //echo "<pre>"; print_r($customer);
        $customer_data = array();
        $customer_data['customer_id'] = $customer->getId();
        $customer_data['website_id'] = $customer->getStoreId();
        $customer_data['firstname'] = $customer->getFirstname();
        $customer_data['lastname'] = $customer->getLastname();
        $customer_data['email'] = $customer->getEmail();
        $customer_data['created_at'] = $customer->getCreatedAt();
        $customer_data['updated_at'] = $customer->getUpdatedAt();
        $customer_data['magento_url'] = $this->storeManager->getStore()->getBaseUrl();
        //echo "<pre>"; print_R($customer_data);
        $data = urlencode(json_encode($customer_data));
        $url_data = 'data='.$data;
        $link = 'https://elliot.global/magento2/magento2-customer-create?'.$url_data;
        
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => $link,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => false,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_SSL_VERIFYPEER=> false,
            CURLOPT_HTTPHEADER => array(
                "cache-control: no-cache",
                "postman-token: 13021bca-a51d-4711-2046-c6f02e0bf74d"
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

//        if ($err) {
//            echo "cURL Error #:" . $err;
//        } else {
//            echo $response;
//        }
//        die('That sit !');
    }
} 