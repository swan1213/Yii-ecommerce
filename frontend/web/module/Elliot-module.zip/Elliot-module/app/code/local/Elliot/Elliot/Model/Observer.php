<?php 
class Elliot_Elliot_Model_Observer extends Mage_Sales_Model_Order {
    public function productUpdateObserver($observer) {
        $_product = $observer->getEvent()->getProduct();
        $product_data = array();
        $product = Mage::getModel('catalog/product')->load($_product->getId());
        $store_ids = $product->getStoreIds();
        $product_name = $product->getName();
        $product_sku = $product->getSku();
        $product_type = $product->getTypeId();
        $product_categories_ids = $product->getCategoryIds();
        $product_description = $product->getDescription();
        $product_weight = $product->getWeight();
        $qty = (int)Mage::getModel('cataloginventory/stock_item')->loadByProduct($product)->getQty();
        $stock_status = $product->getIsInStock();
        $product_status = $product->getStatus();
        $product_created_at = $product->getCreated_at();
        $product_updated_at = $product->getUpdated_at();
        $product_price = $product->getPrice();
        $base_img = Mage::getModel('catalog/product_media_config')->getMediaUrl($product->getImage());
        
        $product_data['magento_url'] = Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_WEB);
        $product_data['product_id'] = $_product->getId();
        $product_data['name'] = $product_name;
        $product_data['sku'] = $product_sku;
        $product_data['product_type'] = $product_type;
        $product_data['description'] = $product_description;
        $product_data['weight'] = $product_weight;
        $product_data['qty'] = $qty;
        $product_data['in_stock_status'] = $stock_status;
        $product_data['product_status'] = $product_status;
        $product_data['product_created_at'] = $product_created_at;
        $product_data['product_updated_at'] = $product_updated_at;
        $product_data['price'] = $product_price;
        $product_data['base_img'] = $base_img;
        
        
        $product_img = array();
        $product_img_array = array();
        $product_position_array = array();
        foreach ($product->getMediaGalleryImages() as $image)  
        {                                                                                                                                       
            $product_img_array[] = $image->getUrl();
            $product_position_array[] = $image->getPosition();
        }
        $product_data['images'] = $product_img_array;
        $product_data['position'] = $product_position_array;
        $product_data['websites'] = $store_ids;
        $product_data['categories'] = $product_categories_ids;
        
        $data = urlencode(json_encode($product_data));
        $url_data = 'data='.$data;
        $link = 'https://elliot.global/magento/magento-product-create';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $link);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS,$url_data);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        $result = curl_exec($ch);
        curl_close($ch);
    }
    
    public function oderCreateObserver(Varien_Event_Observer $observer)
    {
        $order = $observer->getEvent()->getOrder();
        $order_data = Mage::getModel('sales/order')->load($order->getId());

        $order_detail = array();
        $order_id = $order_data->getId();
        $order_state = $order_data->getState();
        $order_status = $order_data->getStatus();
        $order_store_id = $order_data->getStoreId();
        $order_total = $order_data->getBaseGrandTotal();
        $customer_email = $order_data->getCustomerEmail();
        $order_shipping_amount = $order_data->getBaseShippingAmount();
        $order_tax_amount = $order_data->getBaseTaxAmount();
        $order_product_qty = $order_data->getTotalQtyOrdered();
        $customer_id = $order_data->getCustomerId();
        $order_created_at = $order_data->getCreatedAt();
        $order_updated_at = $order_data->getUpdatedAt();
        $refund_amount = $order_data->getSubtotalRefunded();
        $discount_amount = $order_data->getDiscountAmount();
        $payment_method = $order_data->getPayment()->getMethodInstance()->getCode();
        $shipping_method = $order_data->getShippingMethod();
        $orderItems = $order_data->getItemsCollection();
        $order_shipping_add = $order_data->getShippingAddress();
        $order_billing_add = $order_data->getBillingAddress();

        $order_detail['magento_url'] = Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_WEB);
        $order_detail['order_id'] = $order_id;
        $order_detail['order_state'] = $order_state;
        $order_detail['order_status'] = $order_status;
        $order_detail['order_store_id'] = $order_store_id;
        $order_detail['order_total'] = $order_total;
        $order_detail['customer_email'] = $customer_email;
        $order_detail['order_shipping_amount'] = $order_shipping_amount;
        $order_detail['base_tax_amount'] = $order_tax_amount;
        $order_detail['order_product_qty'] = $order_product_qty;
        $order_detail['customer_id'] = $customer_id;
        $order_detail['order_created_at'] = $order_created_at;
        $order_detail['order_updated_at'] = $order_updated_at;
        $order_detail['refund_amount'] = $refund_amount;
        $order_detail['discount_amount'] = $discount_amount;
        $order_detail['payment_method'] = $payment_method;
        $order_detail['shipping_method'] = $shipping_method;


        /**
        * Order Shipping address
        */
        $shipping_details = array();
        $ship_state = $order_shipping_add->getRegion();
        $ship_zip = $order_shipping_add->getPostcode();
        $ship_address = $order_shipping_add->getStreet();
        $ship_city = $order_shipping_add->getCity();
        $ship_customer_email = $order_shipping_add->getEmail();
        $ship_phone = $order_shipping_add->getTelephone();
        $ship_country_id = $order_shipping_add->getCountryId();
        $ship_firstname = $order_shipping_add->getFirstname();
        $ship_lastname = $order_shipping_add->getLastname();
        $ship_middlename = $order_shipping_add->getMiddlename();

        $shipping_details['region'] = $ship_state;
        $shipping_details['postcode'] = $ship_zip;
        $shipping_details['street'] = $ship_address;
        $shipping_details['city'] = $ship_city;
        $shipping_details['email'] = $ship_customer_email;
        $shipping_details['telephone'] = $ship_phone;
        $shipping_details['country_id'] = $ship_country_id;
        $shipping_details['firstname'] = $ship_firstname;
        $shipping_details['lastname'] = $ship_lastname;
        $shipping_details['middlename'] = $ship_middlename;

        $order_detail['shipping_detail'] = $shipping_details;

        $shipping_address = $ship_address . "," . $ship_city . "," . $ship_state . "," . $ship_zip . "," . $ship_country_id;

        /**
        * Order Billing address
        */
        $billing_details = array();
        $bill_state = $order_billing_add->getRegion();
        $bill_zip = $order_billing_add->getPostcode();
        $bill_address = $order_billing_add->getStreet();
        $bill_city = $order_billing_add->getCity();
        $bill_customer_email = $order_billing_add->getEmail();
        $bill_phone = $order_billing_add->getTelephone();
        $bill_country_id = $order_billing_add->getCountryId();
        $bill_firstname = $order_billing_add->getFirstname();
        $bill_lastname = $order_billing_add->getLastname();
        $bill_middlename = $order_billing_add->getMiddlename();

        $billing_details['region'] = $bill_state;
        $billing_details['postcode'] = $bill_zip;
        $billing_details['street'] = $bill_address;
        $billing_details['city'] = $bill_city;
        $billing_details['email'] = $bill_customer_email;
        $billing_details['telephone'] = $bill_phone;
        $billing_details['country_id'] = $bill_country_id;
        $billing_details['firstname'] = $bill_firstname;
        $billing_details['lastname'] = $bill_lastname;
        $billing_details['middlename'] = $bill_middlename;

        $order_detail['billing_detail'] = $billing_details;

        /**
         * Order Items
        */
        $order_items = array();
        foreach($orderItems as $_items)
        {
            $items = array();
            $items['name'] = $_items->getName();
            $items['qty_ordered'] = (int)$_items->getQtyOrdered();
            $items['price'] = $_items->getPrice();
            $items['sku'] = $_items->getSku();
            $items['product_id'] = $_items->getProductId();
            $items['weight'] = $_items->getWeight();
            $order_items[] = $items;

        }

        $order_detail['order_items'] = $order_items;
        $data = urlencode(json_encode($order_detail));
        $url_data = 'data='.$data;
        $link = 'https://elliot.global/magento/magento-order-create';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $link);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS,$url_data);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        $result = curl_exec($ch);
        curl_close($ch);
    }
    
    public function magentoCustomerRegister($observer)
    {
        $customer = $observer->getEvent()->getCustomer();
        $customer_data = array();
        $customer_data['customer_id'] = $customer->getId();
        $customer_data['website_id'] = $customer->getStoreId();
        $customer_data['firstname'] = $customer->getFirstname();
        $customer_data['lastname'] = $customer->getLastname();
        $customer_data['email'] = $customer->getEmail();
        $customer_data['created_at'] = $customer->getCreatedAt();
        $customer_data['updated_at'] = $customer->getUpdatedAt();
        $customer_data['magento_url'] = Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_WEB);
        
        $data = urlencode(json_encode($customer_data));
        $url_data = 'data='.$data;
        $link = 'https://elliot.global/magento/magento-customer-create';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $link);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS,$url_data);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        $result = curl_exec($ch);
        curl_close($ch);
    }
    
    public function magentoCustomerAddressUpdate($observer)
    {
        $customer = $observer->getEvent()->getCustomerAddress();
        $customer_address_data = array();
        $customer_address_data['fistname'] = $customer->getFirstname();
        $customer_address_data['lastname'] = $customer->getLastname();
        $customer_address_data['street'] = $customer->getStreet();
        $customer_address_data['city'] = $customer->getCity();
        $customer_address_data['country_id'] = $customer->getCountryId();
        $customer_address_data['region'] = $customer->getRegion();
        $customer_address_data['postcode'] = $customer->getPostcode();
        $customer_address_data['telephone'] = $customer->getTelephone();
        $customer_address_data['customer_id'] = $customer->getCustomerId();
        $customer_address_data['magento_url'] = Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_WEB);
        
        $data = urlencode(json_encode($customer_address_data));
        $url_data = 'data='.$data;
        $link = 'https://elliot.global/mageonto/magento-customer-address-update';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $link);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS,$url_data);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        $result = curl_exec($ch);
        curl_close($ch);
    }
    
}       